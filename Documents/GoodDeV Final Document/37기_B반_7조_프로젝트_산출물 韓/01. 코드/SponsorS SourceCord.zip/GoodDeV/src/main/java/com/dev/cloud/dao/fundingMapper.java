package com.dev.cloud.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.RowBounds;

import com.dev.cloud.vo.Crowdfunding;

public interface fundingMapper {
	
	public int getBoardCount(Map<String, Object> map);
	
	public List<Crowdfunding> selectAll(Map<String, String> map, RowBounds rb);
	
	public Crowdfunding selectOneCrowdFunding(int boardNum);
	
	public int makeCrowdFunding(Crowdfunding crowdfunding);
	
	public List<Crowdfunding> mypageFunding(String memberId);
	
	public Crowdfunding selectfundingTitle(String fundingTitle);
	
	public int updateCurrentPrice(Crowdfunding crowdfunding);
}
