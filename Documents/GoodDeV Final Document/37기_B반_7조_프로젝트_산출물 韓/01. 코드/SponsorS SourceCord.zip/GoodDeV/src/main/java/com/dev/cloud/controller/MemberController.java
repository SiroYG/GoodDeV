package com.dev.cloud.controller;

import java.util.ArrayList;

import java.util.List;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import com.dev.cloud.dao.PatentRepository;
import com.dev.cloud.dao.PatentSubRepository;
import com.dev.cloud.dao.PtiRepository;
import com.dev.cloud.dao.documentRepository;
import com.dev.cloud.dao.itemRepository;
import com.dev.cloud.dao.memberRepository;
import com.dev.cloud.utill.FileService;
import com.dev.cloud.vo.ItemDo;
import com.dev.cloud.vo.PTI;
import com.dev.cloud.vo.Pat;
import com.dev.cloud.vo.Patent;
import com.dev.cloud.vo.PatentTotal;
import com.dev.cloud.vo.Total;
import com.dev.cloud.vo.devMember;

@Controller
@RequestMapping("/member")
public class MemberController {

	final String uploadPath = "/PatentSub";

	@Autowired
	memberRepository dao;
	@Autowired
	PatentRepository papo;
	@Autowired
	itemRepository itpo;
	@Autowired
	PatentSubRepository pspo;
	@Autowired
	documentRepository dopo;
	@Autowired
	PtiRepository ptipo;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String gomain() {
		return "/index";
	}

	@RequestMapping(value = "/home", method = RequestMethod.GET)
	public String main() {
		return "redirect:/";
	}

	@RequestMapping(value = "/gologin", method = RequestMethod.GET)
	public String gologin() {
		return "/member/login";
	}

	@RequestMapping(value = "/gosign", method = RequestMethod.GET)
	public String gosign() {
		return "/member/signin";
	}

	@RequestMapping(value = "/gofindid", method = RequestMethod.GET)
	public String gofindid() {
		return "/member/findid";
	}

	@RequestMapping(value = "/gofindpw", method = RequestMethod.GET)
	public String gofindpw() {
		return "/member/findpw";
	}

	@RequestMapping(value = "/goupdate", method = RequestMethod.GET)
	public String goupdate() {
		return "/member/update";
	}

	@RequestMapping(value = "/godropout", method = RequestMethod.GET)
	public String godropout() {
		return "/member/dropout";
	}

	@RequestMapping(value = "/goMypage", method = RequestMethod.GET)
	public String goMypage() {

		return "/member/Mypage";
	}

	@RequestMapping(value = "/error", method = RequestMethod.GET)
	public String error() {

		return "/member/error";
	}

	@RequestMapping(value = "/searchGo", method = RequestMethod.GET)
	public String searhGo() {

		return "search/search_patent";
	}

	@ResponseBody
	@RequestMapping(value = "/selectPatent", method = RequestMethod.GET)
	public String selectPatent(Patent patent) {
		Patent pat = null;
		if (patent.getPatentNum() != null) {
			pat = papo.selectPatent(patent);
		}
		return pat.getPatentNum();

	}

	@ResponseBody
	@RequestMapping(value = "/patentSu", method = RequestMethod.GET)
	public int patentSu() {
		List<Patent> pList = papo.patentAll();
		return pList.size();
	}

	@ResponseBody
	@RequestMapping(value = "/patentTable", method = RequestMethod.GET)
	public List<Patent> patentTable(Pat pat, HttpSession session, int pageSu) {
		if (pat.getPatentType() != null) {
			List<Patent> pList = papo.searchPatent(pat);

			List<Patent> result = new ArrayList<Patent>();

			for (int i = 0; i < pList.size(); i++) {
				if (i > pageSu - 10) {
					if (i <= pageSu) {
						result.add(pList.get(i));
					}
				}
			}
			return result;
		} else {
			String patentHolderName = (String) session.getAttribute("loginName");
			List<Patent> cList = papo.patentIdAll(patentHolderName);
			List<Patent> pResult = new ArrayList<Patent>();

			for (int i = 0; i < cList.size(); i++) {
				if (i > pageSu - 10) {
					if (i <= pageSu) {
						pResult.add(cList.get(i));
					}
				}
			}
			return pResult;
		}

	}

	@RequestMapping(value = "/goPatent", method = RequestMethod.GET)
	public String goPatent() {

		return "search/search_menu";
	}

	@ResponseBody
	@RequestMapping(value = "/patinsertForm", method = RequestMethod.POST)
	public String patinsertForm(MultipartFile upload, PatentTotal paten, HttpSession session) {
		Random random = new Random();
		int i = random.nextInt(9999) + 1000;
		int j = random.nextInt(999999) + 1000;
		String total = "KR10-";
		String dasi = "-";
		String patentNum = "";
		patentNum = total + i + dasi + j;
		Patent patent = papo.patsearchNum(patentNum);
		if (patent == null) {
			paten.setPatentNum(patentNum);
		} else {
			paten.setPatentNum(patentNum + "1");
		}
		int result = 0;
		int re = 0;
		String memberId = (String) session.getAttribute("loginId");
		paten.setMemberId(memberId);
		String referenceFilename = upload.getOriginalFilename();
		String saveReferenceFilename = FileService.saveFile(upload, uploadPath);
		paten.setReferenceFilename(referenceFilename);
		paten.setSaveReferenceFilename(saveReferenceFilename);
		devMember mem = dao.selectmemId(memberId);
		System.out.println("214번줄mem==>" + mem);
		if (!mem.getMemberType().equals("client")) {
			result = papo.insertPatent(paten);
			re = pspo.insertPatentsub(paten);
		}
		if (result == 1 && re == 1) {
			return "success";
		} else {
			return "false";
		}

	}

	@ResponseBody
	@RequestMapping(value = "/itemSu", method = RequestMethod.GET)
	public int itemSu(Total total, HttpSession session) {
		String memberId = (String) session.getAttribute("loginId");
		total.setMemberId(memberId);
		List<Total> iList = itpo.getItemByMemberId(total);
		return iList.size();
	}

	@ResponseBody
	@RequestMapping(value = "/itemTable", method = RequestMethod.GET)
	public List<Total> patentTable(HttpSession session, Total total, int pageSu) {
		String memberId = (String) session.getAttribute("loginId");
		total.setMemberId(memberId);
		List<Total> iList = itpo.getItemByMemberId(total);
		List<Total> result = new ArrayList<Total>();

		for (int i = 0; i < iList.size(); i++) {
			if (i > pageSu - 10) {
				if (i <= pageSu) {
					result.add(iList.get(i));
				}
			}
		}
		return result;
	}

	@ResponseBody
	@RequestMapping(value = "/overlap", method = RequestMethod.GET)
	public String overlap(String memberId) {
		System.out.println("memberId==>" + memberId);
		devMember overlapId = dao.overlap(memberId);
		try {
			if (overlapId == null) {
				return "success";
			} else {
				return "fail";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return "success";
	}

	@RequestMapping(value = "/loginform", method = RequestMethod.POST)
	public String login(devMember member, HttpSession session) {
		devMember mem = dao.login_member(member);
		if (mem != null) {
			if (!mem.getMemberType().equals("none")) {
				session.setAttribute("loginId", mem.getMemberId());
				session.setAttribute("loginName", mem.getMemberName());
				session.setAttribute("loginType", mem.getMemberType());
				return "redirect:/";
			}
		} else {
			return "redirect:/";
		}
		return "redirect:/";
	}

	@RequestMapping(value = "/signupform", method = RequestMethod.POST)
	public String signup_member(devMember member, HttpSession session) {
		try {
			int signup = dao.signup_member(member);
			if (signup == 1) {
				
				return "redirect:/";
			} else {
				
				return "redirect:/member/gosign";
			}
		} catch (Exception e) {
			return "redirect:/member/gosign";
		}

	}

	@RequestMapping(value = "/updateform", method = RequestMethod.POST)
	public String update_member(devMember member, HttpSession session) {
		try {
			int update = dao.update_member(member);
			if (update == 1) {
				
				return "redirect:/";
			} else {
				return "redirect:/member/goMypage";
			}
		} catch (Exception e) {
			return "redirect:/member/goMypage";
		}
	}

	@RequestMapping(value = "/dropoutform", method = RequestMethod.POST)
	public String dropout_member(devMember member, HttpSession session) {
		try {
			int dropout = dao.delete_member(member);
			if (dropout == 1) {
				return "redirect:/";
			} else {
				return "redirect:/member/goMypage";
			}
		} catch (Exception e) {
			return "redirect:/member/goMypage";
		}

	}

	@ResponseBody
	@RequestMapping(value = "/searchId", method = RequestMethod.POST)
	public String searchId_member(devMember member) {
		devMember searchId_pw = dao.searchId_pw_member(member);
		try {
			if (searchId_pw != null) {
				
				return searchId_pw.getMemberId();

			} else {
	
				return "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return searchId_pw.getMemberId();
	}

	@ResponseBody
	@RequestMapping(value = "/searchPw", method = RequestMethod.POST)
	public String searchpw_member(devMember member) {
		devMember searchId_pw = dao.searchId_pw_member(member);
		try {
			if (searchId_pw != null) {
				
				return searchId_pw.getMemberPw();
			} else {
				return "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return searchId_pw.getMemberPw();
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

	@ResponseBody
	@RequestMapping(value = "/permitForm", method = RequestMethod.POST)
	public String permitForm(MultipartFile upload, MultipartFile upload1, ItemDo itemdo) {

		int re = 0;
		int result = 0;
		int ptiResult = 0;
		ItemDo sub = pspo.selectPatSub(itemdo);
		itemdo.setPatentsubNum(sub.getPatentsubNum());
		if (upload == null || upload1 == null) {
			re = itpo.updateItemDo(itemdo);
			result = dopo.insertDocument(itemdo);
		} else if (upload.getSize() == 0 || upload.isEmpty() || upload1.getSize() == 0 || upload1.isEmpty()) {
			re = itpo.updateItemDo(itemdo);
			result = dopo.insertDocument(itemdo);

		} else {
			PTI pti = new PTI();
			pti.setItemNum(itemdo.getItemNum());
			pti.setPatentNum(itemdo.getPatentNum());
			PTI p = ptipo.ptiNums(pti);

			if (p == null) {
				String referenceFilename = upload.getOriginalFilename();

				String saveReferenceFilename = FileService.saveFile(upload, uploadPath);

				String documentFilename = upload1.getOriginalFilename();
				String saveDocumentFilename = FileService.saveFile(upload1, uploadPath);
				itemdo.setDocumentFilename(referenceFilename + "@" + documentFilename);
				itemdo.setSaveDocumentFilename(saveReferenceFilename + "@" + saveDocumentFilename);
				ptiResult = ptipo.insertPTI(itemdo);
				re = itpo.updateItemDo(itemdo);
				result = dopo.insertDocument(itemdo);
			}
			if (result == 1 && re == 1 && ptiResult == 1) {
				return "success";
			} else {
				return "false";
			}
		}
		return "success";
	}

	@ResponseBody
	@RequestMapping(value = "/memberItemNum", method = RequestMethod.GET)
	public List<Total> memberItemNum(Total total) {

		List<Total> result = itpo.getItemByMemberId(total);

		return result;
	}

	@RequestMapping(value = "/fileDownload")
	public void fileDownload(HttpSession session, HttpServletRequest req, HttpServletResponse res, ModelAndView mav) throws Throwable {
		String document_nm = "특허 서식 파일 모음.zip";
		String documentName = document_nm;

		String savedDocumentFileName = "patentFile.zip";

		try {
			FileService.filDown(req, res, "/PatentSub" + "/", savedDocumentFileName, documentName);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
