package com.dev.cloud.dao;


import com.dev.cloud.vo.Document;
import com.dev.cloud.vo.ItemDo;
import com.dev.cloud.vo.PdpVo;

public interface documentMapper {
		
	public int insertDocument(ItemDo itemdo);

	public int updateDocument(ItemDo itemdo);
	
	public int updateDocu(PdpVo pdp);
	
	public Document selectDocu(int DocumentNum);
}
