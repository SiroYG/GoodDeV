package com.dev.cloud.dao;

import com.dev.cloud.vo.devMember;

public interface memberMapper {

	public int signup_member(devMember member);

	public devMember login_member(devMember member);

	public devMember searchId_pw_member(devMember member);

	public int update_member(devMember member);

	public int delete_member(devMember member);

	public devMember overlap(String memberId);
	
	public int devmemberPrice(devMember devmember);
	
	public devMember selectmemId(String memberId);
}
