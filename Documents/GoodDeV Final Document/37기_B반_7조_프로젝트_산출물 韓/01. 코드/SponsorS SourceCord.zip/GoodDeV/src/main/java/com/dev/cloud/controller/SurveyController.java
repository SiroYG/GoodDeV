package com.dev.cloud.controller;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.bind.annotation.RequestParam;
import com.dev.cloud.dao.itemRepository;
import com.dev.cloud.dao.item_SurveyRepository;
import com.dev.cloud.utill.FileService;
import com.dev.cloud.utill.PageNavigator;
import com.dev.cloud.vo.Item;
import com.dev.cloud.vo.Question;
import com.dev.cloud.vo.QuestionTotal;
import com.dev.cloud.vo.Question_Time;
import com.dev.cloud.vo.Search;
import com.dev.cloud.vo.Survey;
import com.dev.cloud.vo.Total;

@Controller
@RequestMapping("/survey")
public class SurveyController {

	@Autowired
	item_SurveyRepository IsRepo;

	@Autowired
	itemRepository Irepo;

	@RequestMapping(value = "/goSurvey_list", method = RequestMethod.GET)
	public String goSurvey_list(@RequestParam(value = "currentPage", defaultValue = "1") int currentPage,HttpSession session, Model model) {
		String sessionId = (String) session.getAttribute("loginId");
		Question_Time qTime = new Question_Time();
		ArrayList<QuestionTotal> qTotalList = new ArrayList<>();
		ArrayList<QuestionTotal> getQTList = new ArrayList<>();
		getQTList = IsRepo.selectAllQuestion_TimeById(qTime);

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date today = new Date();
		
		if (getQTList.size() != 0) {
			for (QuestionTotal qtemp : getQTList) {
				String dueDate = qtemp.getDueDate();
				try {
					Date tempDueDate = sdf.parse(dueDate);
					int compare = 0;
					compare = tempDueDate.compareTo(today);
		
					if (compare == 1 && !qtemp.getMemberId().equals(sessionId)) {

						qTotalList.add(qtemp);
					}
					// 같은 날짜일 경우에도 가져오기 위함.
					String tempStrToday = sdf.format(today);
					String tempStrDuedate = sdf.format(tempDueDate);
					if (tempStrToday.equals(tempStrDuedate) && !qtemp.getMemberId().equals(sessionId)) {
						qTotalList.add(qtemp);
					}
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
		}

		int totalRecordCount = IsRepo.selectAllQuestion_TimeById(qTime).size();
		System.out.println(totalRecordCount);
		PageNavigator navi = new PageNavigator(currentPage, totalRecordCount);

		model.addAttribute("qTotalList", qTotalList);
	
		Total total = new Total();
		total.setMemberId(sessionId);
		List<Total> iList = Irepo.getItemByMemberId(total);
		model.addAttribute("iList", iList);
		model.addAttribute("navi", navi);

		return "/survey/survey_list";
	}

	@RequestMapping(value = "/goSurvey_list", method = RequestMethod.POST)
	public String goSurvey_list(HttpSession session, Model model, Question_Time question_Time, Question question) {
		IsRepo.insertQuestion_Time(question_Time);

		Question_Time questionTimeNum = IsRepo.getQuestionTimeNumByItemNumandTitle(question_Time);
		
		String getQeustion = question.getQuestion();
		String[] arrGetQuestion = getQeustion.split(",");
		Question que = new Question();
		for (String temp : arrGetQuestion) {
			que.setQuestion(temp);
			que.setQuestionTimeNum(questionTimeNum.getQuestionTimeNum());
			IsRepo.insertQuestion(que);
		}


		return "redirect:goSurvey_list";
	}

	@RequestMapping(value = "/gosurvey_Detail", method = RequestMethod.GET)
	public String gosurvey_Detail(Model model, Question_Time question_Time) {
		Question_Time question_time = new Question_Time();
		question_time.setQuestionTimeNum(question_Time.getQuestionTimeNum());
		ArrayList<Question> qList = new ArrayList<>();
		String str1 = "";
		Question_Time qTime = new Question_Time();
		qTime = IsRepo.getQuestion_TimeByQuestion_TimeNum(question_time);
		
		Question Qtemp = new Question();
		
		Qtemp.setQuestionTimeNum(question_Time.getQuestionTimeNum());
		Item item = IsRepo.getItembyqtNum(question_Time);
		qList = IsRepo.getQuestionByQuestionTimeNum(Qtemp);
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Calendar time = Calendar.getInstance();
		String times = format.format(time.getTime());

		String splitStr = item.getItemImagename();
		if (splitStr != null) {
			String[] temp = splitStr.split("@");
			str1 = temp[0];
			if (temp.length == 2) {
				String str2 = temp[1];
				model.addAttribute("str2", ", " + str2);

			}
		}

		model.addAttribute("str1", str1);
		model.addAttribute("item", item);
		model.addAttribute("qTime", qTime);
		model.addAttribute("qList", qList);
		model.addAttribute("qtnum", question_Time.getQuestionTimeNum());
		model.addAttribute("time", times);

		return "/survey/survey_Detail";
	}

	@RequestMapping(value = "/insertSurveyDatas", method = RequestMethod.POST)
	public String insertSurveyDatas(Model model) {

		return "redirect:goSurvey_list";
	}

	@RequestMapping(value = "/getSurvey_Detail", method = RequestMethod.POST)
	@ResponseBody
	public String getSurvey_Detail(Model model, @RequestBody HashMap<String, Object> params) {
		String etc = (String) params.get("etc");
		ArrayList<HashMap<String, Integer>> question = (ArrayList<HashMap<String, Integer>>) params.get("params");
	
		Survey s = new Survey();

		for (int i = 0; i < question.size(); i++) {

			if (question.get(i) != null) {

				s.setQuestionNum(question.get(i).get("questionNum"));
				s.setQValuable(question.get(i).get("qValuable"));
				IsRepo.insertSurvey(s);
				
			}
		}
		Question q = new Question();
		q.setQuestionNum(s.getQuestionNum());
		ArrayList<Question> qtemp = IsRepo.getQuestionByQuestionNum(q);
		int QTNUM = qtemp.get(0).getQuestionTimeNum();

		Question_Time qtime = new Question_Time();
		qtime.setQuestionTimeNum(QTNUM);
		qtime = IsRepo.getQuestion_TimeByQuestion_TimeNum(qtime);
		
		if (qtime.getEtc() == null) {
			qtime.setEtc(etc);
		} else {
			qtime.setEtc(qtime.getEtc() + "\n" + etc);
		}

		IsRepo.writeEtc(qtime);

		return "true";
	}

	@RequestMapping(value = "/searchSurvey", method = RequestMethod.GET)
	@ResponseBody
	public List<QuestionTotal> searchSurvey(Model model, Search search, HttpSession session) {
		List<QuestionTotal> qtLsist = new ArrayList<>();
		
		qtLsist = IsRepo.selectBySearchItem();
		
		String sessionId = (String) session.getAttribute("loginId");
		ArrayList<QuestionTotal> qTotalList = new ArrayList<>();

		if (qtLsist.size() == 0 || qtLsist == null) {
			return qtLsist;
		}

		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date today = new Date();
		for (QuestionTotal qtemp : qtLsist) {
			String dueDate = qtemp.getDueDate();
			try {
				Date tempDueDate = sdf.parse(dueDate);
				int compare = 0;
				compare = tempDueDate.compareTo(today);
				if (compare == 1 && !qtemp.getMemberId().equals(sessionId)) {
					qTotalList.add(qtemp);
				}
				String tempStrToday = sdf.format(today);
				String tempStrDuedate = sdf.format(tempDueDate);
				if (tempStrToday.equals(tempStrDuedate) && !qtemp.getMemberId().equals(sessionId)) {
					qTotalList.add(qtemp);
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		return qTotalList;
	}
	@RequestMapping(value = "/goSurvey_form", method = RequestMethod.GET)
	public String goSurvey_form(Model model, Item item) {
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
		Calendar time = Calendar.getInstance();
		String times = format.format(time.getTime());

		model.addAttribute("times", times);

		Item getOneItem = Irepo.selectItemNum(item.getItemNum());
		model.addAttribute("getOneItem", getOneItem);

		return "/survey/survey_form";
	}

	@RequestMapping(value = "/getSurveyListById", method = RequestMethod.GET)
	@ResponseBody
	public List<QuestionTotal> getSurveyListById(Model model, HttpSession session) {
		List<QuestionTotal> qtList = new ArrayList<QuestionTotal>();
		Question_Time qtime = new Question_Time();
		String memberId = (String) session.getAttribute("loginId");

		qtime.setMemberId(memberId);
	
		qtList = IsRepo.selectAllQuestion_TimeById(qtime);

		return qtList;

	}

	@RequestMapping(value = "/gosurvey_result", method = RequestMethod.GET)
	public String gosurvey_result(Model model, Item item, Question_Time qTime) {
		int questionTimeNum = qTime.getQuestionTimeNum();
		Question_Time getQTime = IsRepo.getQuestion_TimeByQuestion_TimeNum(qTime);

		model.addAttribute("getQTime", getQTime);

		int itemNum = getQTime.getItemNum();
		Total itemTemp = new Total();
		itemTemp.setItemNum(itemNum);
		itemTemp = Irepo.getOneItemByItemNum(itemTemp);
		model.addAttribute("itemTemp", itemTemp);

		Question temp = new Question();
		temp.setQuestionTimeNum(questionTimeNum);
		
		ArrayList<Question> questionList = new ArrayList<>();
		questionList = IsRepo.getQuestionByQuestionTimeNum(temp);
		
		ArrayList<Survey> surList = new ArrayList<>();
		Survey surveyTemp = new Survey();
		model.addAttribute("questionList", questionList);

		for (Question question : questionList) {
			int questionNum = question.getQuestionNum();
			surveyTemp.setQuestionNum(questionNum);
			surList = IsRepo.getqValueableByQuestionNum(surveyTemp);
			int getAvgSurvey = 0;
		
			if (surList.size() == 0) {
				return "/survey/survey_result";
			}

			for (Survey survey : surList) {
				getAvgSurvey += survey.getQValuable();
			}
			getAvgSurvey = getAvgSurvey / surList.size();
			question.setAvgSurvey(getAvgSurvey);
		}
		return "/survey/survey_result";
	}

	@RequestMapping(value = "/download1")
	public void download1(@RequestParam("itemNum") int itemNum, HttpSession session, HttpServletRequest req,HttpServletResponse res, ModelAndView mav) throws Throwable {
	
		Item item = Irepo.selectItemNum(itemNum);
		
		String documentFilename = item.getItemImagename();
		String saveDocumentFilename = item.getSaveItemImage();
		String[] allSplitForDoc = documentFilename.split("@");
		String[] allSplitForSaveDoc = saveDocumentFilename.split("@");
		
		String imagename = allSplitForDoc[0];
		String documentName = allSplitForSaveDoc[0];

		try {
			FileService.filDown(req, res, "/FileTest" + "/", documentName, imagename); 
		} catch (Exception e) {
			e.printStackTrace();

		}

	}

	@RequestMapping(value = "/download2")
	public void download2(@RequestParam("itemNum") int itemNum, HttpSession session, HttpServletRequest req, HttpServletResponse res, ModelAndView mav) throws Throwable {
		Item item = Irepo.selectItemNum(itemNum);
		
		String documentFilename = item.getItemImagename();
		String saveDocumentFilename = item.getSaveItemImage();
		String[] allSplitForDoc = documentFilename.split("@");
		String[] allSplitForSaveDoc = saveDocumentFilename.split("@");
		
		String imagename = allSplitForDoc[1];
		String documentName = allSplitForSaveDoc[1];

		try {
			FileService.filDown(req, res, "/FileTest" + "/", documentName, imagename);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}
