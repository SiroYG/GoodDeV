package com.dev.cloud.controller;



import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.dev.cloud.dao.chatRoomRopository;
import com.dev.cloud.dao.fundingOptionRepository;
import com.dev.cloud.dao.fundingRepository;
import com.dev.cloud.dao.itemRepository;
import com.dev.cloud.dao.memberRepository;
import com.dev.cloud.utill.FileService;
import com.dev.cloud.utill.PageNavigator;


import com.dev.cloud.vo.ChatMember;
import com.dev.cloud.vo.ChatRoom;
import com.dev.cloud.vo.ChatTotal;
import com.dev.cloud.vo.Crowdfunding;
import com.dev.cloud.vo.Item;
import com.dev.cloud.vo.Payment;
import com.dev.cloud.vo.devMember;


@Controller
@RequestMapping("/funding")
public class FundingController {

	@Autowired
	fundingOptionRepository dao1;
	@Autowired
	fundingRepository dao;
	@Autowired
	chatRoomRopository crRepo;
	@Autowired
	memberRepository mempo;
	@Autowired
	itemRepository itpo;
	
	//final String uploadPath = "/uploadfile";
	//final String uploadPath ="C:/Users/Administrator/Desktop/apache-tomcat-9.0.22/webapps/cloud/resources/img";
	final String uploadPath="C:/Users/창민/Documents/GitHub/GoodDeV/ChanMin/workspace/GoodDeV/src/main/webapp/resources/img";
	
	@RequestMapping(value = "/boardhome", method = RequestMethod.GET)
	public String boardhome() { 
		return "/board/Board_list";
	}
	@RequestMapping(value = "/gofunding", method = RequestMethod.GET)
	public String gofunding() { 
		return "/funding/funding_list";
	}
	@RequestMapping(value = "/gofundingform", method = RequestMethod.GET)
	public String gofundingform() {
		return "/funding/funding_form";
	}
	@RequestMapping(value = "/gopayment", method = RequestMethod.GET)
	public String gopayment(@RequestParam(value = "itemname", defaultValue = "paymentTest") String itemname ,Model model) { 
		model.addAttribute("itemname",itemname);
		return "/funding/payment";
	}
	
	@ResponseBody
	@RequestMapping(value="myfundList", method= RequestMethod.GET)
	public List<Crowdfunding> myfundList(HttpSession session){
		String memberId = (String) session.getAttribute("loginId");
		
		List<Crowdfunding> cList = dao.mypageFunding(memberId);
		
		return cList;
	}
	
	
	@RequestMapping(value = "fundingListForm", method = RequestMethod.GET)
	public String fundingListForm(@RequestParam(value = "searchItem", defaultValue = "fundingTitle") String searchItem,
			@RequestParam(value = "searchWord", defaultValue = "") String searchWord,
			@RequestParam(value = "currentPage", defaultValue = "1") int currentPage, Model model) {
		int totalRecordCount = dao.getBoardCount(searchItem, searchWord);
		System.out.println(totalRecordCount);
		PageNavigator navi = new PageNavigator(currentPage, totalRecordCount);
		System.out.println(navi.getStartRecord());
		List<Crowdfunding> list = dao.selectAll(searchItem, searchWord, navi.getStartRecord(), navi.getCountPerPage());
		System.out.println(list.size());

		model.addAttribute("searchItem", searchItem);
		model.addAttribute("searchWord", searchWord);
		model.addAttribute("navi", navi);
		model.addAttribute("list", list);

		return "/funding/funding_list";
	}

	@RequestMapping(value = "fundingDetail", method = RequestMethod.GET)
	public String fundingDetail(int crowdfundingNum, Model model) {
		Crowdfunding Crowdfunding = dao.selectOneCrowdFunding(crowdfundingNum);
	
		int percent =(Crowdfunding.getItemCurrecyPrice()*100 / Crowdfunding.getItemGoalPrice());
		
		model.addAttribute("fund", Crowdfunding);
		model.addAttribute("percent",percent);
		model.addAttribute("save",Crowdfunding.getSavedFileName());
		
		return "/funding/funding_Detail";
	}
	@ResponseBody
	@RequestMapping(value = "/fundTitle", method = RequestMethod.GET)
	public List<Item> fundTitle(String memberId) {
		System.out.println("131번줄memberId==>"+memberId);
		
		List<Item> iList = itpo.selectItemMem(memberId);
		
		return iList;
	}
	
	@ResponseBody
	@RequestMapping(value = "/selectFundingTitle", method = RequestMethod.GET)
	public String selectFundingTitle(String fundingTitle) {
		Crowdfunding crowd = dao.selectfundingTitle(fundingTitle);
		if(crowd==null){
			return "success";
		}else{
			return "false";
		}
		
	}
	
	@RequestMapping(value = "/fundingWrite", method = RequestMethod.POST)
	public String fundingWrite(Crowdfunding Crowdfunding, MultipartFile upload) {
		try {
			String originalFileName = upload.getOriginalFilename();
			String savedFileName = FileService.saveFile(upload, uploadPath);
			Crowdfunding.setOriginalFileName(originalFileName);
			Crowdfunding.setSavedFileName(savedFileName);
		} catch (IllegalStateException e) {
			e.printStackTrace();
		}
	
		int result = dao.makeCrowdFunding(Crowdfunding);
		if(result>0){
			return "redirect:/funding/fundingListForm";
		}else{
			return "redirect:/funding/gofundingform";
		}
		
	}

	@ResponseBody
	@RequestMapping(value = "devmemberPrice", method = RequestMethod.GET)
	public String devmemberPrice(HttpSession session,Payment payment,int amount) {
		String memberId = (String) session.getAttribute("loginId");
		
		devMember member = mempo.selectmemId(memberId);
		member.setFundPrice(member.getFundPrice()+amount);
		payment.setAmount(payment.getAmount()+member.getFundPrice());
		int result = mempo.devmemberPrice(member);
		Crowdfunding crowd = dao.selectOneCrowdFunding(payment.getCrowdfundingNum());
		crowd.setItemCurrecyPrice(crowd.getItemCurrecyPrice()+amount);
		int crowResult = dao.updateCurrentPrice(crowd); 
		if(result==1&&crowResult==1){
			return "success";
		}else{
			return "false";
		}	
	}
	
	@RequestMapping(value = "paymentform", method = {RequestMethod.POST,RequestMethod.GET})
	public String paymentform(Payment payment, Model model) {
		model.addAttribute("payment", payment);
		return "/funding/payment";
	}
	
	@RequestMapping(value = "fundingChat", method = RequestMethod.GET)
	public String fundingChat(Payment payment, Model model, ChatRoom chatRoom, HttpSession session) {
		String SessionTemp=(String) session.getAttribute("loginId");
		ArrayList<ChatMember> AllcmList=new ArrayList<>();
		AllcmList=crRepo.getAllchatMemberByCrowdfundingNum(chatRoom);
		
		ArrayList<ChatRoom> AllcrList=new ArrayList<>();
		AllcrList=crRepo.getAllchatRoomByCrowdfundingNum(chatRoom);

		ArrayList<ChatMember> cmforLeftList=new ArrayList<>();
		
		ArrayList<Integer> checkAchatRoomSeq=new ArrayList<>();
		
		for (ChatRoom chatrm : AllcrList){

			for(ChatMember cMember : AllcmList){

				int Chatroom_seq=0;
				if(chatrm.getChatroom_seq()==cMember.getChatroom_seq()&&cMember.getMemberId().equals(SessionTemp)){
					Chatroom_seq=chatrm.getChatroom_seq();
							
					checkAchatRoomSeq.add(Chatroom_seq);
					break;
					
				}
			}
		}
		for(int i : checkAchatRoomSeq){
			for(ChatMember cMember : AllcmList){
				if(i==cMember.getChatroom_seq()){
					cmforLeftList.add(cMember);
					break;
				}
			}
		}
		
		ArrayList<ChatMember> cmforRightList=new ArrayList<>();
		Crowdfunding Crowdfunding=new Crowdfunding();
		Crowdfunding = dao.selectOneCrowdFunding(chatRoom.getCrowdfundingNum());

		if(cmforLeftList.size()!=0){
			int chatRoomNum=cmforLeftList.get(0).getChatroom_seq();
			
			ArrayList<ChatMember> ndList = crRepo.getAllchatMemberByCrowdfundingNumNotDesc(chatRoom);
			for(ChatMember cMember : ndList){
			if(cMember.getChatroom_seq()==chatRoomNum){
				cmforRightList.add(cMember);
			}
			}
		}
		model.addAttribute("cmforLeftList", cmforLeftList);
		model.addAttribute("cmforRightList", cmforRightList);
		model.addAttribute("Crowdfunding", Crowdfunding);

		return "/funding/chat_popup";
	}

	@RequestMapping(value = "/getAllchat", method = RequestMethod.GET)
	@ResponseBody
	public List<ChatMember> getAllchat(ChatMember chatMember, HttpSession session) {
		List<ChatMember> cmList=new ArrayList<>();
		
		cmList=crRepo.getAllchatByChatRM(chatMember);
		
		String memberId=(String) session.getAttribute("loginId");
		boolean flag=false;
		
		for(ChatMember  member: cmList){
			if(member.getMemberId().equals(memberId)){
				flag=true;
				break;
			}
		}
		if(flag==false){
			return null;
		}
		return cmList;
	}
	@RequestMapping(value = "/writeChat", method = RequestMethod.POST)
	@ResponseBody
	public String writeChat(ChatMember chatMember) {
		
		int result =crRepo.sendMessage(chatMember);
		
		return "success";
	}
	
	@RequestMapping(value = "/getAllchatroom", method = RequestMethod.GET)
	@ResponseBody
	public ArrayList<ChatMember> getAllchatroom(ChatRoom chatRoom, HttpSession session) {
		ArrayList<ChatMember> AllcmList=new ArrayList<>();
		AllcmList=crRepo.getAllchatMemberByCrowdfundingNum(chatRoom);
		ArrayList<ChatRoom> AllcrList=new ArrayList<>();
		AllcrList=crRepo.getAllchatRoomByCrowdfundingNum(chatRoom);
		ArrayList<ChatMember> cmforLeftList=new ArrayList<>();
		String memberId=(String) session.getAttribute("loginId");
		
		ArrayList<Integer> checkAchatRoomSeq=new ArrayList<>();
		for (ChatRoom chatrm : AllcrList){
			for(ChatMember cMember : AllcmList){
				if(chatrm.getChatroom_seq()==cMember.getChatroom_seq()&cMember.getMemberId().equals(memberId)){		
					checkAchatRoomSeq.add(cMember.getChatroom_seq());
					break;
				}
			}
		}
		
		for(int num : checkAchatRoomSeq){
			for(ChatMember cMember : AllcmList){
				if(num==cMember.getChatroom_seq()){
					cmforLeftList.add(cMember);
					break;
				}
			}
		}

		return cmforLeftList;
	}
	
	@RequestMapping(value = "/makeChatroom", method = RequestMethod.POST)
	@ResponseBody
	public ChatMember makeChatroom(ChatTotal chatTotal) {

		int CrowdfundingNum=chatTotal.getCrowdfundingNum();
		Crowdfunding crowdfunding=new Crowdfunding();
		crowdfunding=dao.selectOneCrowdFunding(CrowdfundingNum);
		
		ChatRoom chatRoomTemp=new ChatRoom();
		chatRoomTemp.setCrowdfundingNum(CrowdfundingNum);
		crRepo.getAllchatMemberByCrowdfundingNum(chatRoomTemp);
		ArrayList<ChatMember> cmList=new ArrayList<>();
		for(ChatMember member: cmList){
			if(member.getMemberId().equals(chatTotal.getMemberId())){
				return null;
			}
		}
		
		ChatRoom chatRoom=new ChatRoom();
		chatRoom.setCrowdfundingNum(CrowdfundingNum);
		System.out.println(chatRoom);
		int temp=crRepo.insertChatRoom(chatRoom);
		
		int chatroom_seq=chatRoom.getChatroom_seq();
		
		ChatMember chatMember=new ChatMember();
		String message="님이 입장하셨습니다.";
		chatMember.setChatroom_seq(chatroom_seq);
		chatMember.setMemberId(chatTotal.getMemberId());
		chatMember.setMessage(chatTotal.getMemberId()+message);
		crRepo.sendMessage(chatMember);

		chatMember.setMemberId(crowdfunding.getMemberId());
		chatMember.setMessage(crowdfunding.getMemberId()+message);
		
		crRepo.sendMessage(chatMember);
		
		
		return chatMember;
	}
	
}
