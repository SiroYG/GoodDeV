package com.dev.cloud.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.RowBounds;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.dev.cloud.vo.Board;

@Repository
public class boardRepository {
	
	@Autowired
	private SqlSession sqlSession;

	public int getBoardCount(String searchItem, String searchWord) {

		boardMapper mapper = sqlSession.getMapper(boardMapper.class);
		Map<String, Object> map = new HashMap<>();
		map.put("searchItem", searchItem);
		map.put("searchWord", searchWord);
		
		int total = mapper.getBoardCount(map);	
		return total;
	}

	public List<Board> userboard(String memberId){
		boardMapper mapper = sqlSession.getMapper(boardMapper.class);
		return mapper.userboard(memberId);
	}

	
	public List<Board> selectAll(String searchItem, String searchWord, int startRecord, int countPerPage) {
		
		List<Board> list;
		
		RowBounds rb = new RowBounds(startRecord, countPerPage);
		boardMapper mapper = sqlSession.getMapper(boardMapper.class);

		Map<String, String> map = new HashMap<>();
		map.put("searchItem", searchItem);
		map.put("searchWord", searchWord);
		
		list = mapper.selectAll(map, rb);
		
		return list;
	}

	public Board selectOne(Board board) {
		boardMapper mapper = sqlSession.getMapper(boardMapper.class);
		Board result = null;
		
		result = mapper.selectOne(board);

		return result;
	}

	public int deleteBoard(int boardNum) {
		boardMapper mapper = sqlSession.getMapper(boardMapper.class);
		int result = mapper.deleteBoard(boardNum);
		return result;
	}

	public int insertBoard(Board board) {
		boardMapper mapper = sqlSession.getMapper(boardMapper.class);

		int result = mapper.insertBoard(board);
		return result;
	}
	public int updateBoard(Board board) {
		boardMapper mapper = sqlSession.getMapper(boardMapper.class);
		int result = mapper.updateBoard(board);
		return result;
	}
}
