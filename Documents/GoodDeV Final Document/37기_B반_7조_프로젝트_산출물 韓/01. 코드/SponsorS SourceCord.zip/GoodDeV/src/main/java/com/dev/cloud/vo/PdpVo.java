package com.dev.cloud.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PdpVo { 
	
	private int itemNum;
	private String  itemImagename ;
	private String  saveItemImage ;

	private String patentNum ;
	private String patentName ;
	private String patentHolderName ;
	private String patenttype ;

	private int  PTI_seq ;
	private String  contract ;
	private String  contractDate ;

	public String memberId;
	public String memberName;
	public String memberGo;

	private int patentsubNum;
	
	private int DocumentNum;
	private String documentFilename;
	private String saveDocumentFilename;
}
