package com.dev.cloud.dao;

import java.util.ArrayList;
import java.util.List;

import com.dev.cloud.vo.Item;
import com.dev.cloud.vo.Question;
import com.dev.cloud.vo.QuestionTotal;
import com.dev.cloud.vo.Survey;
import com.dev.cloud.vo.Question_Time;

public interface item_SurveyMapper {

	public int insertQuestion_Time(Question_Time question_Time);

	public int insertQuestion(Question qustion);
	
	public ArrayList<Question_Time> getQuestion_TimeByItemNum(Question_Time question_Time);

	public ArrayList<Question> getQuestionByQuestionTimeNum(Question qustion);

	public int updateQuestion_Time(Question_Time question_Time);

	public int updateQuestion(Question qustion);

	public int writeEtc(Question_Time question_Time);

	public int deleteQuestion(Question question);

	public int insertSurvey(Survey survey);

	public ArrayList<Survey> getqValueableByQuestionNum(Survey survey);

	public int deleteQuestion_Time(Question_Time question_Time);
	
	public ArrayList<QuestionTotal> selectAllQuestion_TimeById(Question_Time Question_Time);
	
	public List<QuestionTotal> selectBySearchItem();
	
	public Question_Time getQuestion_TimeByQuestion_TimeNum(Question_Time question_Time);
	
	public ArrayList<Question> getQuestionByQuestionNum(Question question);
	
	public Question_Time getQuestionTimeNumByItemNumandTitle(Question_Time question_Time);
	
	public Item getItembyqtNum(Question_Time question_Time);
	 
}
