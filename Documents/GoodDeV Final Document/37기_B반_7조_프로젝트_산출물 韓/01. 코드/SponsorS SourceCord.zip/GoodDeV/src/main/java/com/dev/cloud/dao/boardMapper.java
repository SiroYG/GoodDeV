package com.dev.cloud.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.RowBounds;

import com.dev.cloud.vo.Board;


public interface boardMapper {

	
	int getBoardCount(Map<String, Object> map);
	
	List<Board> selectAll(Map<String, String> map, RowBounds rb);
	
	Board selectOne(Board board);
	
	int deleteBoard(int boardNum);
	
	int insertBoard(Board board);
	
	int updateBoard(Board Board);

	List<Board> userboard(String memberId);

}
