package com.dev.cloud.dao;

import java.util.ArrayList;
import java.util.List;

import com.dev.cloud.vo.Item;
import com.dev.cloud.vo.ItemDo;
import com.dev.cloud.vo.PdpVo;
import com.dev.cloud.vo.Total;


public interface itemMapper {

		public int insertItem(Total total);

		public ArrayList<Total> getItemNumByItemType(Total total);

		public ArrayList<Total> getAllItem();
		
		public Total goItemDetail(Total total);

		public List<Total> getItemByMemberId(Total total);
		
		public List<Total> getIdDe(Total total);

		public int updateItem(Total total);
		
		public Total gohisD(Total total);

		public int deleteItem(Total total);
		
		public int updateItemDo(ItemDo itemdo);
		
		public Item selectItemNum(int itemNum);
		
		public int pdpUpdate(PdpVo pd);
		
		public Total getOneItemByItemNum(Total total);
		
		public List<Item> selectItemMem(String memberId);
		
		public Item selectItemName(String itemName);
}
