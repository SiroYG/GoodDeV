package com.dev.cloud.dao;

import java.util.ArrayList;

import com.dev.cloud.vo.ChatMember;
import com.dev.cloud.vo.ChatRoom;

public interface chatRoomMapper {
	
	public int insertChatRoom(ChatRoom chatRoom);
	
	public int sendMessage(ChatMember chatMember);
	
	public ArrayList<ChatMember> getAllchatMemberByCrowdfundingNum(ChatRoom chatRoom);
	
	public ArrayList<ChatRoom> getAllchatRoomByCrowdfundingNum(ChatRoom chatRoom);
	
	public ArrayList<ChatMember> getAllchatMemberByCrowdfundingNumNotDesc(ChatRoom chatRoom);

	public ArrayList<ChatMember> getAllchatByChatRM(ChatMember chatMember);
	
	public int getLastChatroom_seq();
}
