package com.dev.cloud.utill;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.FileCopyUtils;
import org.springframework.web.multipart.MultipartFile;


public class FileService {

	public static String saveFile(MultipartFile upload, String uploadPath) {
	
		File path = new File(uploadPath);
		if (!path.isDirectory()) {
			path.mkdirs();
		}

		String originalFilename = upload.getOriginalFilename();
		
		if(originalFilename.trim().length() == 0 || upload.isEmpty()) 
			return "";
		
		String sdf = UUID.randomUUID().toString();
	
		String filename;		
		String ext;				
		String savedFilename;	
		
		int lastIndex = originalFilename.lastIndexOf('.');
		
		if (lastIndex == -1) {
			ext = "";
			filename= originalFilename;
		}
		
		else {
			ext = "." + originalFilename.substring(lastIndex + 1);
			filename= originalFilename.substring(0, lastIndex);
		}
		
		filename = filename+"_"+sdf + ext;
		savedFilename = filename;	
		
		String serverFile = uploadPath + "/" +savedFilename;	
	
		try {
			upload.transferTo(new File(serverFile)); 
		} catch (Exception e) {
			savedFilename = null;
			e.printStackTrace();
		}
		
		return savedFilename;
	}
	
	public static boolean deleteFile(String fullpath) {
		boolean result = false;
		
		File delFile = new File(fullpath);
		
		if (delFile.isFile()) {
			delFile.delete();
			result = true;
		}
		
		return result;
	}
	

	public static void filDown(HttpServletRequest request,
			HttpServletResponse response, String filePath, String realFilNm,
			String viewFileNm) throws IOException {
		 
		File file = new File( filePath + realFilNm);
		System.out.println("root = " + filePath + realFilNm);
		if (file.exists() && file.isFile()) {
			response.setContentType("application/octet-stream; charset=utf-8");
			response.setContentLength((int) file.length());
			String browser = getBrowser(request);
			String disposition = getDisposition(viewFileNm, browser);
			response.setHeader("Content-Disposition", disposition);
			response.setHeader("Content-Transfer-Encoding", "binary");
			OutputStream out = response.getOutputStream();
			FileInputStream fis = null;
			fis = new FileInputStream(file);
			FileCopyUtils.copy(fis, out);
			if (fis != null)
				fis.close();
			out.flush();
			out.close();
		}
	}

	private static String getBrowser(HttpServletRequest request) {
		String header = request.getHeader("User-Agent");
		if (header.indexOf("MSIE") > -1 || header.indexOf("Trident") > -1)
			return "MSIE";
		else if (header.indexOf("Chrome") > -1)
			return "Chrome";
		else if (header.indexOf("Opera") > -1)
			return "Opera";
		return "Firefox";
	}

	private  static String getDisposition(String filename, String browser)
			throws UnsupportedEncodingException {
		String dispositionPrefix = "attachment;filename=";
		String encodedFilename = null;
		if (browser.equals("MSIE")) {
			encodedFilename = URLEncoder.encode(filename, "UTF-8").replaceAll(
					"\\+", "%20");
		} else if (browser.equals("Firefox")) {
			encodedFilename = "\""
					+ new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
		} else if (browser.equals("Opera")) {
			encodedFilename = "\""
					+ new String(filename.getBytes("UTF-8"), "8859_1") + "\"";
		} else if (browser.equals("Chrome")) {
			StringBuffer sb = new StringBuffer();
			for (int i = 0; i < filename.length(); i++) {
				char c = filename.charAt(i);
				if (c > '~') {
					sb.append(URLEncoder.encode("" + c, "UTF-8"));
				} else {
					sb.append(c);
				}
			}
			encodedFilename = sb.toString();
		}
		return dispositionPrefix + encodedFilename;
	}
	
	
}
