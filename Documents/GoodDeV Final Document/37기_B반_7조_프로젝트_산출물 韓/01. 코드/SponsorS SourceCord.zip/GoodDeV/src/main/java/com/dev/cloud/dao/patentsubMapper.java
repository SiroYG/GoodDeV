package com.dev.cloud.dao;

import com.dev.cloud.vo.ItemDo;
import com.dev.cloud.vo.PatentTotal;
import com.dev.cloud.vo.Patentsub;

public interface patentsubMapper {

		public int insertPatentsub(PatentTotal paten);
	
		public int updatePatentsub(Patentsub patentsub);
	
		public ItemDo selectPatSub(ItemDo itemdo);
		
		public Patentsub selectSub(String patentNum);
}
