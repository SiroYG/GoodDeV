package com.dev.cloud.dao;

import com.dev.cloud.vo.ItemDo;
import com.dev.cloud.vo.PTI;
import com.dev.cloud.vo.PdpVo;

public interface PTIMapper {

		public int insertPTI(ItemDo itemdo);

		public int updatePTI(PdpVo pdp);

		public PTI selectPti(int PTI_seq);
		
		public PTI ptiNums(PTI pti);
}
