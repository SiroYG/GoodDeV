package good.dev.support01.dao;

public interface boardMapper {

	
	
}
