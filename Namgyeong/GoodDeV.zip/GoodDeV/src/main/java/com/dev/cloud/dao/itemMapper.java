package com.dev.cloud.dao;

public interface itemMapper {

	
	
}
