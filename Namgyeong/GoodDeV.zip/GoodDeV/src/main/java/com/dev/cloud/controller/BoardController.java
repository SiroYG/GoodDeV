package com.dev.cloud.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/board")
public class BoardController {

	/*@Autowired
	boardRepository dao;*/
	
	@RequestMapping(value = "/gowrite", method = RequestMethod.GET)
	public String gowrite() { // 작성 페이지 이동
		return "/board/Board_Write";
	}
	
	@RequestMapping(value = "/goboard", method = RequestMethod.GET)
	public String goboardlist() { // 리스트 이동
		return "/board/Board_list";
	}
	
	@RequestMapping(value = "/goupdate", method = RequestMethod.GET)
	public String goupdate() { // 수정 페이지 이동
		return "/board/Board_update";
	}
	
	@RequestMapping(value = "/godelete", method = RequestMethod.GET)
	public String godetail() { // 상세보기
		return "/board/Board_Detail";
	}
	
	@RequestMapping(value = "/godelete", method = RequestMethod.GET)
	public String godelete() { // 삭제
		return "redirect:/board/Board_list";
	}
	
}
