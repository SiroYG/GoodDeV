package com.dev.cloud.dao;

public interface patentsubMapper {

	
	
}
