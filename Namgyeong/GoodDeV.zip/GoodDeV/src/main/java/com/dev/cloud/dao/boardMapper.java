package com.dev.cloud.dao;

public interface boardMapper {

	
	
}
