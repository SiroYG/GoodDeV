package com.dev.cloud.dao;

public interface historyMapper {

	
	
}
